<?php

XTS\Registry::getInstance()->activation->form();
